package com.sandy.sunsangit;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.sandy.sunsangit.R;

public class customAdapter extends ArrayAdapter<String> {
    String[] items;

    public customAdapter(@NonNull Context context, int resource,@NonNull String[] items) {
        super(context, resource,items);
        this.items=items;
    }
    @Nullable
    @Override
    public String getItem(int position) {

        return items[position];
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_list,parent,false);
        TextView textsong = convertView.findViewById(R.id.txtsongname);
        textsong.setSelected(true);
        textsong.setText(items[position]);
        return convertView;
        //use for click listener
        //before returning the view add click listener

    }
}
