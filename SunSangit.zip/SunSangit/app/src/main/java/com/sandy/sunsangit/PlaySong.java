package com.sandy.sunsangit;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.gauravk.audiovisualizer.visualizer.BarVisualizer;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class PlaySong extends AppCompatActivity {
    TextView textView, player_position, player_duration;
    ImageView previous, play,shuffle, next,repeatall,addtofav,playlist;
    ImageView repeat_ones;
    MediaPlayer mediaPlayer;
    ArrayList<File> songs;
    String textContent;
    SeekBar seekBar;
    int Position;
    Thread updateSeek;
    Handler handler = new Handler();
    Runnable runnable;
    BarVisualizer visualizer;
    int duration;


    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        mediaPlayer.release();
        updateSeek.interrupt();
        if(visualizer !=null)
        {
            visualizer.release();
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_song);
        textView = findViewById(R.id.textView);
        play = findViewById(R.id.play);
        previous = findViewById(R.id.previous);
        next = findViewById(R.id.next);
        seekBar = findViewById(R.id.seekBar);
        visualizer=findViewById(R.id.blast);
        player_position = findViewById(R.id.player_position);
        player_duration = findViewById(R.id.player_duration);
       // repeatall=findViewById(R.id.repeatall);
     //   repeat_ones=findViewById(R.id.repeat_ones);
     //   shuffle=findViewById(R.id.shuffle);


        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        songs = (ArrayList) bundle.getParcelableArrayList("songList");
        textContent = intent.getStringExtra("currentSong");

        textView.setSelected(true);
        Position = intent.getIntExtra("Position", 0);

        Uri uri = Uri.parse(songs.get(Position).toString());
        String textContent1=songs.get(Position).getName();
        textView.setText(textContent1);
        mediaPlayer = MediaPlayer.create(this, uri);
        mediaPlayer.start();
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                try {
                    mediaPlayer.start();
                  //  repeatall.setImageResource(R.drawable.repeatall);
                    mediaPlayer.setLooping(true);
                    seekBar.setProgress(0);//use to restart the seekbar
                    //Some extra
                  //  Toast.makeText(PlaySong.this, "ReapetAll", Toast.LENGTH_SHORT).show();
                    mediaPlayer.seekTo(0);
                    //Some extra
                }catch (Exception e){
                    e.printStackTrace();
                }

            }
        });
        int audiosessionId=mediaPlayer.getAudioSessionId();
        if(audiosessionId !=-1)
        {
            visualizer.setAudioSessionId(audiosessionId);
        }

        seekBar.setMax(mediaPlayer.getDuration());
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                //someextra
                if (fromUser) {
                    mediaPlayer.seekTo(progress);
                }
                player_position.setText(convertFormat(mediaPlayer.getCurrentPosition()));//someextra
                player_duration.setText(convertFormat(mediaPlayer.getDuration()));
            }


            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mediaPlayer.seekTo(seekBar.getProgress());
            }
        });
        //some extra
        //initialize runnable
        runnable = new Runnable() {
            @Override
            public void run() {
                seekBar.setProgress(mediaPlayer.getCurrentPosition());
                handler.postDelayed(this, 500);
            }
        };
        int duration = mediaPlayer.getDuration();
        String sDuration = convertFormat(duration);
        player_duration.setText(sDuration);////someextra
        updateSeek = new Thread() {
            @Override
            public void run() {
                int currentPosition = 0;
                try {
                    while (currentPosition < mediaPlayer.getDuration()) {
                        currentPosition = mediaPlayer.getCurrentPosition();
                        seekBar.setProgress(currentPosition);
                        sleep(800);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        updateSeek.start();
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                    play.setImageResource(R.drawable.play);
                    handler.removeCallbacks(runnable);
                    int audiosessionId=mediaPlayer.getAudioSessionId();
                    if(audiosessionId !=-1)
                    {
                        visualizer.setAudioSessionId(audiosessionId);
                    }

                    int currentposition = mediaPlayer.getCurrentPosition();
                    int duration = mediaPlayer.getDuration();

                    if (mediaPlayer.isPlaying() && duration != currentposition) {
                        currentposition = currentposition + 5000;
                        player_position.setText(convertFormat(currentposition));
                        mediaPlayer.seekTo(currentposition);

                    }
                }
                else {
                    mediaPlayer.start();
                    play.setImageResource(R.drawable.paused);
                    handler.postDelayed(runnable, 0);

                }



            }
        });
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
                mediaPlayer.release();
                if (Position != 0) {
                    Position = Position - 1;
                } else {
                    Position = songs.size() - 1;
                }
                Uri uri = Uri.parse(songs.get(Position).toString());
                mediaPlayer = MediaPlayer.create(getApplicationContext(), uri);
                mediaPlayer.start();

                seekBar.setMax(mediaPlayer.getDuration());
                textContent = songs.get(Position).getName().toString();
                textView.setText(textContent);
                int audiosessionId=mediaPlayer.getAudioSessionId();
                if(audiosessionId !=-1)
                {
                    visualizer.setAudioSessionId(audiosessionId);
                }


            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               // mediaPlayer.seekTo(0);
                if (Position != songs.size() - 1) {
                    Position = Position + 1;
                } else {
                    Position = 0;
                }
                mediaPlayer.stop();
                mediaPlayer.release();
                Uri uri = Uri.parse(songs.get(Position).toString());
                mediaPlayer = MediaPlayer.create(getApplicationContext(), uri);
                mediaPlayer.start();

                seekBar.setMax(mediaPlayer.getDuration());
                textContent = songs.get(Position).getName().toString();
                textView.setText(textContent);
                int audiosessionId=mediaPlayer.getAudioSessionId();
                if(audiosessionId !=-1)
                {
                    visualizer.setAudioSessionId(audiosessionId);
                }

            }
        });


        ////someextra

    }
    @SuppressLint("DefaultLocale")
    private String convertFormat(int duration) {
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(duration),
                TimeUnit.MILLISECONDS.toSeconds(duration) -
                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration)));
    }

}
